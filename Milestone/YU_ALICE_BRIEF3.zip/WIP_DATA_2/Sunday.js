//Notifications received on the 16/08/20
 [
    {
          "12:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
          }
    },

    {
         "1:00 am": {
        "instagram": 1,
        "messenger": 2,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
         }
    },
    
    
    {
         "2:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "3:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "4:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "5:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "6:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "7:00 am": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "8:00 am": {
        "instagram": 2,
        "messenger": 2,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 5
         }
    },
    
    {
         "9:00 am": {
        "instagram": 2,
        "messenger": 0,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 3
         }
    },
    
    {
         "10:00 am": {
        "instagram": 1,
        "messenger": 2,
        "snapchat": 3,
        "email": 0,
        "facebook": 2,
        "totalNotification": 8
         }
    },
    
    {
         "11:00 am": {
        "instagram": 0,
        "messenger": 2,
        "snapchat": 7,
        "email": 2,
        "facebook": 0,
        "totalNotification": 11
         }
    },
    
    {
        "12:00 pm": {
        "instagram": 0,
        "messenger": 1,
        "snapchat": 2,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
        }
    },
    
    {
         "1:00 pm": {
        "instagram": 4,
        "messenger": 0,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 5
         }
    },
    
    {
         "2:00 pm": {
        "instagram": 2,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 2
         }
    },
    
    {
         "3:00 pm": {
        "instagram": 0,
        "messenger": 2,
        "snapchat": 4,
        "email": 0,
        "facebook": 0,
        "totalNotification": 6
         }
    },
    
    {
         "4:00 pm": {
        "instagram": 5,
        "messenger": 0,
        "snapchat": 3,
        "email": 0,
        "facebook": 0,
        "totalNotification": 8
         }
    },
    
    {
         "5:00 pm": {
        "instagram": 1,
        "messenger": 0,
        "snapchat": 4,
        "email": 0,
        "facebook": 0,
        "totalNotification": 5
         }
    },
    
    {
         "6:00 pm": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
         }
    },
    
    {
         "7:00 pm": {
        "instagram": 1,
        "messenger": 11,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 12
         }
    },
    
    {
         "8:00 pm": {
        "instagram": 0,
        "messenger": 2,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 2
         }
    },
    
    {
         "9:00 pm":{
        "instagram": 0,
        "messenger": 1,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 1
         }
    },
    
    {
        "10:00 pm": {
        "instagram": 7,
        "messenger": 1,
        "snapchat": 21,
        "email": 0,
        "facebook": 0,
        "totalNotification": 29
        }
    },
    
    {
         "11:00 pm": {
        "instagram": 0,
        "messenger": 0,
        "snapchat": 3,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
         }
    }
  ]
