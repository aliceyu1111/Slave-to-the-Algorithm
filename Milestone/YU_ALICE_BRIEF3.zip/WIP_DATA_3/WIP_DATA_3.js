
var data = {};
var Sunday =[];
//var instagram, snapchat, messenger, facebook, email;
var x=x;
var y=y;
var size = size;
let time = (x, y);
let number = size;

function preload (){
  data =loadJSON ("Sunday.js");
}

    
function setup() {
   createCanvas (windowWidth, windowHeight);
   loadData ();
   background (255);
   noStroke ();
   textSize (20);
   let instagram = color (142, 68, 173);
   let messenger = color (133, 193, 233);
   let snapchat = color (247, 220, 111);
   let facebook = color (118, 215, 196);
   let email = color (178, 186, 187); 
   
   var e1 
   if (e1 < 10) {
     ellipse (x,y,10, 10);
   } else {
     ellipse (x,y, 20, 20)
     

   
   // not sure if writing this correct?
   let ellipse1 = (x,y,10, 10);
     if (number(5, 10)) {}
      
     else 
     if (number (10, 15)) {}
   let ellipse2 = (x,y, 20, 20);
      if (number (15, 30)) {}
   let ellipse3 = (x,y,30,30);
   
      }
     
     
function draw () {
  //12:00 am data
  
  fill (messenger);
  text (data.12:00 am.instagram, 210, 200);
  
  
//for (var i=0; i<Sunday.length; i++) {
  //Sunday [i].Sunday();
  //Sunday [i].display ();
  

}
  
