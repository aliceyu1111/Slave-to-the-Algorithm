//Notifications received on the 16/08/20
 [
    {
        "time": "12:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "1:00 am",
        "instagram": 1,
        "messenger": 2,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
    },
    {
        "time": "2:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "3:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "4:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "5:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "6:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "7:00 am",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "8:00 am",
        "instagram": 2,
        "messenger": 2,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 5
    },
    {
        "time": "9:00 am",
        "instagram": 2,
        "messenger": 0,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 3
    },
    {
        "time": "10:00 am",
        "instagram": 1,
        "messenger": 2,
        "snapchat": 3,
        "email": 0,
        "facebook": 2,
        "totalNotification": 8
    },
    {
        "time": "11:00 am",
        "instagram": 0,
        "messenger": 2,
        "snapchat": 7,
        "email": 2,
        "facebook": 0,
        "totalNotification": 11
    },
    {
        "time": "12:00 pm",
        "instagram": 0,
        "messenger": 1,
        "snapchat": 2,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
    },
    {
        "time": "1:00 pm",
        "instagram": 4,
        "messenger": 0,
        "snapchat": 0,
        "email": 1,
        "facebook": 0,
        "totalNotification": 5
    },
    {
        "time": "2:00 pm",
        "instagram": 2,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 2
    },
    {
        "time": "3:00 pm",
        "instagram": 0,
        "messenger": 2,
        "snapchat": 4,
        "email": 0,
        "facebook": 0,
        "totalNotification": 6
    },
    {
        "time": "4:00 pm",
        "instagram": 5,
        "messenger": 0,
        "snapchat": 3,
        "email": 0,
        "facebook": 0,
        "totalNotification": 8
    },
    {
        "time": "5:00 pm",
        "instagram": 1,
        "messenger": 0,
        "snapchat": 4,
        "email": 0,
        "facebook": 0,
        "totalNotification": 5
    },
    {
        "time": "6:00 pm",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 0
    },
    {
        "time": "7:00 pm",
        "instagram": 1,
        "messenger": 11,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 12
    },
    {
        "time": "8:00 pm",
        "instagram": 0,
        "messenger": 2,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 2
    },
    {
        "time": "9:00 pm",
        "instagram": 0,
        "messenger": 1,
        "snapchat": 0,
        "email": 0,
        "facebook": 0,
        "totalNotification": 1
    },
    {
        "time": "10:00 pm",
        "instagram": 7,
        "messenger": 1,
        "snapchat": 21,
        "email": 0,
        "facebook": 0,
        "totalNotification": 29
    },
    {
        "time": "11:00 pm",
        "instagram": 0,
        "messenger": 0,
        "snapchat": 3,
        "email": 0,
        "facebook": 0,
        "totalNotification": 3
    }
  ]
