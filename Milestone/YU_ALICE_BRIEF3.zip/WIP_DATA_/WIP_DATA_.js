class Notify {
  constructor (x, y, time, app, number) {
    this.x = x;
    this.y = y;
    this.time = x,y;
    this. app = colour;
    this.number = size;
        
  }

   
    //this. diameter = number;
    //this. radius = diameter / 2;
    //this. time = time;
    //this. app = app;
       


//display the dots?
//display (); {
  //stroke (0);
  //fill ();
  //ellipse (this.x, this.y, this.number, this. number);
  
}

var data ={};
var Sunday = [];
var instagram, snapchat, messenger, facebook, email, time;


function preload (){
  data =loadJSON ("Sunday.json");
}

function loadData (){
  let SundayData = data ['Sunday'];
  for (let i = 0; i < SundayData.length; i++) {
    let Sunday = SundayData [i];
    let position = time ['position']
    let x = position ['x'];
    let y = position ['y'];
    //let time = ['x, y'];
    let app = ['colour'];
    let number = circle ['diameter'];
  }
}
    
     
function setup() {
   createCanvas (windowWidth, windowHeight);
   loadData ();
   background (0);
   var instagram = color (90);
   var snapchat = color (126);
   var messenger = color (200);
   var facebook = color (50);
   var email = color (100);
   var time = size ;

}

function draw() {
  background (0);
for (var i=0; i<Sunday.length; i++) {
  Sunday[i].Sunday();
  Sunday [i].display ();
  fill (colour);
  ellipse (x, y, size, size);
}
}
