var data; // bucket for the notification data
//each social media notifications count is listed
//value ranges between 0-20 → circles -->map values?
var instagram, snapchat, messenger, facebook, email, instagramCol, snapchatCol, messengerCol, facebookCol, emailCol; 
// this will make the circles bigger
var sizeMultiplier = 20; 
var time, size;

function preload (){
  data =loadJSON ("Sunday.json");
}
function setup() {
   createCanvas (windowWidth, windowHeight);
   background (255);
   noStroke ();
   textSize (20);
   instagramCol = color (142, 68, 173);
   messengerCol = color (133, 193, 233);
   snapchatCol = color (247, 220, 111);
   facebookCol = color (118, 215, 196);
   emailCol = color (178, 186, 187); 
   }
function draw () {
  //12:00 am data
  fill (instagramCol);
size = data[8][0]*sizeMultiplier; 
ellipse (20, 40, size, size);
//fill (snapchatCol);
  //ellipse (90,90,60,60);
  
//for (var i=0; i<data.length; i++) {
  //Sunday [i].Sunday();
  //Sunday [i].display ();   }

}
